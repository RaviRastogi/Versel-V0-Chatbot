import { ChatForm } from '@/components/chat-form'

export default function Page() {
  return <ChatForm />
}

